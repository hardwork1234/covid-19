<template>
    <div class="header"></div>
</template>

<style scoped>

.header{
    width: 100%;
    height: 0;
    position: relative;
    padding-top: 33.5%;
    color: #fff;
    font-size: 0.28rem;
    text-align: center;
    background: url("../assets/1.jpg") no-repeat;
    background-size: cover;
}

</style>