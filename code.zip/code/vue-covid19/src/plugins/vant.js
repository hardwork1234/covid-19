import Vue from 'vue';
import { Cascader } from 'vant';
import { Field } from 'vant';
import { Button } from 'vant';
import { Popup } from 'vant';

Vue.use(Popup);
Vue.use(Button);
Vue.use(Field);
Vue.use(Cascader);