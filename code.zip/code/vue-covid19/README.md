## 关于项目的编写

## 项目组件分类

## 安装依赖
1. npm install --save axios