self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f1c3569a9c9c5346070f",
    "url": "/itbaizhan/covid19/css/app.de51b2b1.css"
  },
  {
    "revision": "28ee750b7f537b0b076d",
    "url": "/itbaizhan/covid19/css/chunk-13a9c2d6.81b82767.css"
  },
  {
    "revision": "a6eb56e7a5e5e5d10cd7",
    "url": "/itbaizhan/covid19/css/chunk-vendors.0bdbce21.css"
  },
  {
    "revision": "71e843df6d5ee52dff0dc6865bb975bd",
    "url": "/itbaizhan/covid19/img/1.71e843df.jpg"
  },
  {
    "revision": "d78442ca2e377f3c97e2c3eef8b78ad5",
    "url": "/itbaizhan/covid19/index.html"
  },
  {
    "revision": "f1c3569a9c9c5346070f",
    "url": "/itbaizhan/covid19/js/app.29d0cb03.js"
  },
  {
    "revision": "28ee750b7f537b0b076d",
    "url": "/itbaizhan/covid19/js/chunk-13a9c2d6.4571b531.js"
  },
  {
    "revision": "a6eb56e7a5e5e5d10cd7",
    "url": "/itbaizhan/covid19/js/chunk-vendors.cc4733d9.js"
  },
  {
    "revision": "4323f18ed5de5ccd49dd6c8eb9816b21",
    "url": "/itbaizhan/covid19/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/itbaizhan/covid19/robots.txt"
  }
]);