import MyComponent from "./MyComponent"

export default (Vue) =>{
    Vue.component(MyComponent.name,MyComponent)
}
