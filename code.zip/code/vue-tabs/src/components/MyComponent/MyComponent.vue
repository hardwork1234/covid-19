<template>
  <div>
      我是一个封住组件
  </div>
</template>

<script>
export default {
    name:"MyComponent"
}
</script>

<style>

</style>