<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png">
    <my-component></my-component>
    <MyComponent />
    <tabs :currentIndex="currentIndex" @onIndex="getIndexHandle">
      <tab index="1" label="中国地图">
        <div>内容1</div>
      </tab>
      <tab index="2" label="世界地图">
        <div>内容2</div>
      </tab>
      <tab index="3" label="我的地图">
        <div>内容3</div>
      </tab>
    </tabs>
  </div>
</template>

<script>

export default {
  name: 'App',
  data(){
    return{
      currentIndex:1
    }
  },
  components: {
  },
  methods:{
    getIndexHandle(index){
      this.currentIndex = index
    }
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
