# 引入Echarts

## 关于安装Echarts的方案
1. 手动引入Echarts，自己封装使用
    - npm install echarts@4.x --save
2. 引入第三方封装好的Echarts
    - https://github.com/ecomfe/vue-echarts

## 注意事项
    4.x:我们当前选择的版本（当前选择）
    5.x:引入地图比较麻烦，我们需要单独找到地图的json资源

## 封装Echarts
